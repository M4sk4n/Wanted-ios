<div class="page" data-name="new">
  <div class="navbar white-back">
    <div class="navbar-bg white-back"></div>
    <div class="navbar-inner sliding">
      <div class="left">
        <a href="/main/" class="link back">
          <i class="icon icon-back"></i>
          <span class="if-not-md">کورد ئەپ</span>
        </a>
      </div>
      <div class="title">چی تازەیە</div>
    </div>
  </div>
  <div class="white-back page-content">
    <div class="block-title block-title-medium" style="text-align: right">2022/7/11</div>
    <div class="block">
      <p style="text-align: right">
        وەک چەند کەسیک هەلساین بە دانانی کورد ئەپ بو
        <br>
        <br>
        ئیوەی ئازیز بو دابەزاندنی بەرنامە هاکا کان 
        <br>
        <br>
        دوربە لەدزینی کودی کورد کورد ئەپ 
        <br>
        <br>
        چاوەروان بن بەم زوانە سوشیالمیدیا یەکاناکاینە وا بە ناوی کورد ئەپ
      </p>
      <br>
       
       
    </div>
  
    <div class="block-title block-title-medium" style="text-align: right"></div>
    <div class="list no-hairlines">
<ul>
  </div>
</div>

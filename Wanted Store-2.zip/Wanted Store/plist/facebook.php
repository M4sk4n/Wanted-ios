
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd …">
<plist version="1.0">
<dict>
<key>items</key>
<array>
<dict>
<key>assets</key>
<array>
<dict>
<key>kind</key>
<string>software-package</string>
<key>url</key>
<string>https://up-ipa.com/uploads/up-ipa.comFacebook-362-0-Wolf[tg-iapps-ipa]_fdb27.ipa</string>
</dict>
<dict>
<key>kind</key>
<string>display-image</string>
<key>url</key>
<string>https://archive.org/download/logo_20240303_20240303/logo.ico</string>
</dict>
<dict>
<key>kind</key>
<string>full-size-image</string>
<key>url</key>
<string>https://kurdapp.tk/icon.png</string>
</dict>
</array>
<key>metadata</key>
<dict>
<key>bundle-identifier</key>
<string>kurd-app.facebook</string>
<key>bundle-version</key>
<string>153.1.2</string>
<key>kind</key>
<string>software</string>
<key>title</key>
<string>
✔ فڵای ستۆری ✔
facebook ++
</string>
</dict> 
</dict>
</array>
</dict>
</plist>
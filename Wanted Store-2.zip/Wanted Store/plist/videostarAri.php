
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd …">
<plist version="1.0">
<dict>
<key>items</key>
<array>
<dict>
<key>assets</key>
<array>
<dict>
<key>kind</key>
<string>software-package</string>
<key>url</key>
<string>https://www86.uptobox.com/dl/8u3KtbK_TzO4DvINjQcHKy3UGSqw8MS0sB98WiYXV9DEK0f2uOpr3CjGwa3R_uMALe3B4PUvZU3447W974be01zgRSvQSFXawz9LjRvzar3b0Fh-2AOR_OPT_JBVAkP-7e5pI5U6sR7G-qpimYwC6w/Fugu14App-resigned.ipa</string>
</dict>
<dict>
<key>kind</key>
<string>display-image</string>
<key>url</key>
<string>https://archive.org/download/logo_20240303_20240303/logo.ico</string>
</dict>
<dict>
<key>kind</key>
<string>full-size-image</string>
<key>url</key>
<string>https://kurdapp.tk/icon.png</string>
</dict>
</array>
<key>metadata</key>
<dict>
<key>bundle-identifier</key>
<string>kurd-app.in.video</string>
<key>bundle-version</key>
<string>9.0</string>
<key>kind</key>
<string>software</string>
<key>title</key>
<string>
✔ فڵای ستۆری ✔
videostar s2
</string>
</dict> 
</dict>
</array>
</dict>
</plist>